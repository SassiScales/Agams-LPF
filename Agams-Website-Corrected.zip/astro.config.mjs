import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://agams-website.vercel.app',
  integrations: [],
});
